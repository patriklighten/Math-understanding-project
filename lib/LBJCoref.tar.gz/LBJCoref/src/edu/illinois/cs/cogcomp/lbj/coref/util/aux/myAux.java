package edu.illinois.cs.cogcomp.lbj.coref.util.aux;

public class myAux {
}


package edu.illinois.cs.cogcomp.lbj.coref.filters;

import edu.illinois.cs.cogcomp.lbj.coref.ir.examples.CExample;

abstract public class CFilter extends Filter<CExample> {
}

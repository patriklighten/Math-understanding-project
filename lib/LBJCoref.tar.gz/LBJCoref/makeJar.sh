
jar cmf Manifest.txt LBJCoref.jar gazetteers wordnet -C class edu

